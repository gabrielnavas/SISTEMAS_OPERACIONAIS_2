#include<stdio.h>
#include<string.h>
#include <stdbool.h>
#include "meuconio.h"

#define NOME_USUARIO_PADRAO "root\0"
#define NOME_GRUPO_PADRAO  "root\0"

// ============================== ESTRUTURAS ==============================
struct inode_extend
{
	int b_diretos[5];
}; 
typedef struct inode_extend InodeExtend;

struct inode_principal
{
	char permissoes[10];
	char data[12];
	char hora[9];
	int tamanho;
	char nome_usuario[100];
	char nome_grupo[100];
	int contador_link_hard;
	
	int b_diretos[5];
	int b_indi_simples;
	int b_indi_duplo;
	int b_indi_triplo;
};
typedef struct inode_principal InodePrincipal;

struct diretorio
{
	int tl;
	
	/* 
		10 ENTRADAS PARA ARQUIVO/DIRETORIO
		2 ENTRADAS PARA DIRETORIO ATUAL E ANTERIOR
		1 ENTRADA PARA EXTENSAO DE DIRETORIO
	*/
	char  nome_arq[13][255];
	int i_numero[13];
	
	struct inode_principal dir_extend;
};
typedef struct diretorio Diretorio;


struct link_simbolico
{
	
};
typedef struct link_simbolico LinkSimb;


struct no_lista_block
{
	int tl;
	int pilha[10];
	int prox;
};


struct block
{
	
//	char tipo; NAO PRECISA DISSO
	
	//ESTRUTURA DE INODE, PODE SER DIRETORIO, PODE SER ARQUIVO OU PODE SER LINK HARD
	struct inode_principal inode;
	
	//ESTRUTURA DE INODE EXTENDIDO
	struct inode_extend inode_extend;
	
	//ESTRUTURA DE DIRETORIO
	struct diretorio diretorio;
	
	//ESTRTURA PARA PILHA DE BLOCOS LIVRES
	struct  no_lista_block no_lista_block;
	
	//ESTRUTURA DE LINK SIMBOLICO
	struct link_simbolico link_simb;
};
typedef struct block Block;


void init_blocos_livres(Block disco[], int total_blocos)
{
	int qnt_blocos, 
		inicio_endereco_block_livres, 
		fim_blocos,
		i,
		j;
	

	inicio_endereco_block_livres = total_blocos/10;
	fim_blocos = total_blocos/10;
	for(i=0 ; i < fim_blocos && inicio_endereco_block_livres < total_blocos; i++)
	{
		disco[i].no_lista_block.tl=-1;
		disco[i].no_lista_block.prox = i+1;
		
		
		disco[i].no_lista_block.tl++;	
		while(disco[i].no_lista_block.tl < 10 && inicio_endereco_block_livres < total_blocos)
		{
//			strcpy(disco[i].tipo, LISTA_BLOCK_FREE);
			disco[i].no_lista_block.pilha[ disco[i].no_lista_block.tl++ ] = inicio_endereco_block_livres;
			
			inicio_endereco_block_livres++;
		}
		
	}
	
	disco[i].no_lista_block.prox = -1;
}

void exibir_blocos_livres(Block disco[], int topo_blocks_free)
{
	int i,
		j;
		
	while(disco[topo_blocks_free].no_lista_block.prox != -1)
	{
		for(j = disco[topo_blocks_free].no_lista_block.tl-1 ; j > -1  ; j--)
			printf("ENDERECO => %d\n", disco[topo_blocks_free].no_lista_block.pilha[j]);
			
		topo_blocks_free++;	
	}
		
}

void pop_lista_block(Block disco[], int * topo_blocks_free, int * endereco)
{
	int tl;
		
	tl = 	disco[*topo_blocks_free].no_lista_block.tl;
	*endereco = disco[*topo_blocks_free].no_lista_block.pilha[tl-1];
	
	disco[*topo_blocks_free].no_lista_block.tl--;
	if(disco[*topo_blocks_free].no_lista_block.tl == 0)
		(*topo_blocks_free)++;
}


void push_lista_block(Block disco[], int * topo_blocks_free, int endereco)
{
	int	tl;
	
	if(disco[*topo_blocks_free].no_lista_block.tl == 10)
		(*topo_blocks_free)--;

		
	tl = 	++disco[*topo_blocks_free].no_lista_block.tl;
	disco[*topo_blocks_free].no_lista_block.pilha[tl] = endereco;
}

int quantidade_blocks_livres(Block disco[], int topo_blocks_free)
{
	int qntd_blocks,
		i,
		j;
	
	qntd_blocks=0;
	while(disco[topo_blocks_free].no_lista_block.prox != -1)
	{
		for(j = disco[topo_blocks_free].no_lista_block.tl-1 ; j > -1  ; j--)
			qntd_blocks++;
			
		topo_blocks_free++;	
	}
	
	return qntd_blocks;
}

void criar_estrutura_diretorio( Block disco[], int * topo_blocks_free, int endereco_atual, int endereco_anterior)
{	
	disco[endereco_atual].diretorio.i_numero[0] = endereco_atual;
	disco[endereco_atual].diretorio.i_numero[1] = (endereco_anterior == -1) ? endereco_atual : endereco_anterior ; 	
	strcpy(disco[endereco_atual].diretorio.nome_arq[0], ".");
	strcpy(disco[endereco_atual].diretorio.nome_arq[1], "..");
	disco[endereco_atual].diretorio.tl=2;	
}

void criar_inode_diretorio( Block disco[], int endereco_inode, int endereco_estrutura_dir)
{
	strcpy(disco[endereco_inode].inode.permissoes, "dRWXRWXRWX");
	strcpy(disco[endereco_inode].inode.data, __DATE__);
	strcpy(disco[endereco_inode].inode.hora, __TIME__);
	disco[endereco_inode].inode.tamanho = 2*10;
	strcpy(disco[endereco_inode].inode.nome_usuario, NOME_USUARIO_PADRAO);
	strcpy(disco[endereco_inode].inode.nome_grupo, NOME_GRUPO_PADRAO);
	disco[endereco_inode].inode.contador_link_hard = 0;
	
	disco[endereco_inode].inode.b_diretos[0] = endereco_estrutura_dir;
}

void criar_diretorio_raiz(Block disco[], int * topo_blocks_free, int * inode_atual)
{
	int endereco_inode,
		endereco_estrutura_dir;
	
	pop_lista_block(disco, &*topo_blocks_free, &endereco_inode);
	pop_lista_block(disco, &*topo_blocks_free, &endereco_estrutura_dir);
	
	criar_inode_diretorio(disco, endereco_inode, endereco_estrutura_dir);
	criar_estrutura_diretorio(disco, &*topo_blocks_free, endereco_estrutura_dir, -1);
	
	*inode_atual = endereco_inode;
}

void inserir_diretorio_in_estrutura_diretorio(Block disco[], int * topo_blocks_free, int inode_atual, char nome_dir[255])
{
	//INSERIR UM DIRETORIO DENTRO DO DIRETORIO ATUAL.
}

void inserir_arquivo_in_estrutura_diretorio(Block disco[], int * topo_blocks_free, int inode_atual, char nome_dir[255])
{
	//INSERIR UM ARQUIVO DENTRO DO DIRETORIO ATUAL
}

//ls
void listar_diretorio(Block disco[], int endereco_dir_atual)
{
	int endereco_struct_dir,
		i,
		j,
		tl_dir;
	
	endereco_struct_dir = disco[endereco_dir_atual].inode.b_diretos[0];
	
	for(i=0 ; i < disco[endereco_struct_dir].diretorio.tl ; i++)
		printf("%s\n", disco[endereco_struct_dir].diretorio.nome_arq[i]);
}

//ls -l
void listar_diretorio_atributos(Block disco[], int endereco_dir_atual)
{
	int endereco_struct_dir,
		endereco_inode,
		i,
		j,
		tl_dir;
	
	endereco_struct_dir = disco[endereco_dir_atual].inode.b_diretos[0];
	
	for(i=0 ; i < disco[endereco_struct_dir].diretorio.tl ; i++)
	{
		if(strcmp(disco[endereco_struct_dir].diretorio.nome_arq[i], ".") != 0 && 
			strcmp(disco[endereco_struct_dir].diretorio.nome_arq[i], "..") !=  0)
		{	
			endereco_inode = disco[endereco_struct_dir].diretorio.i_numero[i];
			
			//COR DIFERENTE POR TIPO DE ARQUIVO
			if(disco[endereco_inode].inode.permissoes[0] == '-')
				textcolor(5);
			else if(disco[endereco_inode].inode.permissoes[0] == 'd')
				textcolor(6);
			else
				textcolor(7);
				
			printf("%s %d %s %s %d %s %s %s\n" ,disco[endereco_inode].inode.permissoes,
								 disco[endereco_inode].inode.contador_link_hard, 
								 disco[endereco_inode].inode.nome_usuario,
								 disco[endereco_inode].inode.nome_grupo,
								 disco[endereco_inode].inode.tamanho,
								 disco[endereco_inode].inode.data,
								 disco[endereco_inode].inode.hora,
								 disco[endereco_struct_dir].diretorio.nome_arq[i]);
			
		}
		else
			printf("%s\n" , disco[endereco_struct_dir].diretorio.nome_arq[i]);
	}
	
	textcolor(15);	
}

void testar_lista_blocos(Block disco[], int topo_blocks_free)
{
	int endereco;
	int i;
	int dir_padrao;
	
	criar_diretorio_raiz(disco, &topo_blocks_free, &dir_padrao);
	listar_diretorio_atributos(disco, dir_padrao);
	
	
	
	exibir_blocos_livres(disco, topo_blocks_free);//
	
	printf("\n\nQUANTIDADE BLOCOS LIVRES: %d\n", quantidade_blocks_livres(disco, topo_blocks_free));
	
	for(i=0 ; i < 9 ; i++)
	{
		pop_lista_block(disco, &topo_blocks_free, &endereco);
		printf("%d\n", endereco);
	}
	
	
	printf("\n\nQUANTIDADE BLOCOS LIVRES: %d\n", quantidade_blocks_livres(disco, topo_blocks_free));
	
	pop_lista_block(disco, &topo_blocks_free, &endereco);
	printf("%d\n", endereco);
			
	printf("\n\nQUANTIDADE BLOCOS LIVRES: %d\n", quantidade_blocks_livres(disco, topo_blocks_free));
}

int main()
{	
	//TAMANHO FISICO DISCO
	int tf_disco = 500;
	
	//DISCO INTEIRO
	Block disco[500];
	
	//TOPO DA LISTA DE BLOCKS
	int topo_blocks_free=0;
		
	//INICIAR LISTA DE PILHA DE BLOCOS COM ENDERECOS
	init_blocos_livres(disco, tf_disco);
	
	//TESTAR GERENCIAMENTO DE ESPACO LIVRE
	testar_lista_blocos(disco, topo_blocks_free);
	
	
		
	
//	ler_comando();
}



////void inserir_inode_extend_simples(ListaPilha lp[], int * tl_lista, Block disco[1000], 
////							Block block_indireto_simples, int *quantidade_block_indireto)
////{
////	int i;
////	Block block_livre;
////	
////	for(i=0 ; i < 5 && *quantidade_block_indireto > 0; i++, (*quantidade_block_indireto)--)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block_indireto_simples.inode_extend.b_diretos[i] = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////	}
////}

////void inserir_inode_extend_duplo(ListaPilha lp[], int * tl_lista, Block disco[1000], 
////							Block block_indireto_duplo, int *quantidade_block)
////{
////	int i, blocos_restantes;
////	Block block_livre;
////	
////	for(i=0 ; i < 5 && *quantidade_block > 0 ; i++)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block_indireto_duplo.inode_extend.b_diretos[i].endereco_disco = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////		
////		inserir_inode_simples(lp, &*tl_lista, disco, block_livre, &*quantidade_block);
////	}
////}*/

////void inserir_inode_extend_triplo(ListaPilha lp[], int * tl_lista, Block disco[1000], 
////							Block block_indireto_triplo, int *quantidade_block)
////{
////	int i, j, blocos_restantes;
////	Block block_livre;
////	
////	for(i=0 ; i < 5 && *quantidade_block ; i++)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block_indireto_triplo.inode_extend.b_diretos[i] = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////		
////		inserir_inode_duplo(lp, &*tl_lista, disco, block_livre, &*quantidade_block);
////	}
////}*/

////void inserir_inode_arquivo( ListaPilha lp[], int * tl_lista, Block disco[1000], 
////							int endereco_block, int quantidade_blocos)
////{
////	/* 
////		PARA USAR ESSA FUNCAO, EH NECESSARIO VERIFICAR ESPACO EM DISCO PARA 
////		A QUANTIDADE DE BLOCOS QUE VAI NO ARQUIVO.
////	
////		lp[] => LISTA DE PILHA DA BLOCOS LIVRES 
////		tl_lista => TAMANHO LOGICO DE lp[]
////		disco[1000] => DISCO INTEIRO
////		endereco_block => POSICAO QUE VAI O ARQUIVO NO DISCO
////		quantidade_blocos => QUANTIDADE DE BLOCOS PARA O ARQUIVO, FORA O PROPRIO ARQUIVO
////	*/
////	
////	Block block, block_livre, block_aux;
////	int i, blocos_alocados;
////	
////	//ARQUIVO REGULAR
//////	strcpy(block.tipo, "IP");
////	block.endereco_disco = endereco_block;
////	block.inode.tamanho = quantidade_blocos * 10;
////	strcpy(block.inode.permissoes, "-RWXRWXRWX");
////	strcpy(block.inode.data, __DATE__);
////	strcpy(block.inode.hora, __TIME__);
////	strcpy(block.inode.nome_usuario, NOME_USUARIO_PADRAO);
////	strcpy(block.inode.nome_grupo, NOME_GRUPO_PADRAO);
////	block.inode.contador_link_hard = 0;
////	
////	inserir_block_disco(disco, block);
////	
////	//INSERIR OS BLOCOS DIRETOS QNTD = 5
////	for(i=0; i < quantidade_blocos && i < 5 ; i++, quantidade_block--)
////	{
////		//PEGA BLOCK DA LISTA DE BLOCOS
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		
////		//ATRIBUI ENDERECO DO BLOCO NA VARIAVEL QUE APONTA
////		block.inode.b_diretos[i] = block_livre.endereco_disco;
////		
////		//ALOCA O BLOCO REGULAR NO DISCO
////		inserir_block_disco(disco, block_aux);
////	}
////	
////	//BLOCOS INDIRETOS SIMPLES QNTD = 10
////	if(quantidade_blocos)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block.inode.b_indi_simples = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////	
////		inserir_inode_extend_simples(disco, block_livre, quantidade_blocos);	
////	}
////	

////	//BLOCOS INDIRETOS DUPLO QNTD = 125
////	if(quantidade_blocos)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block.inode.b_indi_duplo = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////		
////		inserir_inode_extend_duplo(disco, block_livre, quantidade_blocos);
////	}
////	//BLOCO INDIRETO TRIPLO QNTD = 625
////	if(quantidade_blocos)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block.inode.b_indi_triplo = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////		
////		inserir_inode_extend_triplo(disco, block_livre, quantidade_blocos);
////	}
////	
////	//EXTENSAO, COMO FAZER?
////	if(quantidade_blocos)
////	{
////		//O QUE FAZER?
////	}
////}

////void remover_inode_arquivo( ListaPilha lp[], int * tl_lista, Block disco[1000], int endereco_block )
////{
////	Block block_remove, block_direto;
////	int i, quantidade_blocos;
////	
////	block_remove = lp[*endereco_block];
////	quantidade_blocos = (block_remove.tamanho/10)
////	
////	for(i=0 ; i < 5 && quantidade_blocos ; i++, quantidade_blocos--)
////	{
////		disco[block_remove.b_diretos[i]].endereco_disco = 'F';
////		block_remove = disco[block_remove.b_diretos[i]];
////		push_lista_pilha(lp, tl_lista, block_remove);
////	}
////	
////	//BLOCOS INDIRETOS SIMPLES QNTD = 10
////	if(quantidade_blocos)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block.inode.b_indi_simples = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////	
////		inserir_inode_extend_simples(disco, block_livre, quantidade_blocos);	
////		//TEM QUE MOREVER A PROPRIA ESTRTUTURA 
////	}
////	

////	//BLOCOS INDIRETOS DUPLO QNTD = 125
////	if(quantidade_blocos)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block.inode.b_indi_duplo = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////		
////		inserir_inode_duplo(disco, block_livre, quantidade_blocos);
////		//TEM QUE MOREVER A PROPRIA ESTRTUTURA 
////	}
////	//BLOCO INDIRETO TRIPLO QNTD = 625
////	if(quantidade_blocos)
////	{
////		pop_lista_pilha(lp, tl_lista, &block_livre);
////		block.inode.b_indi_triplo = block_livre.endereco_disco;
////		inserir_block_disco(disco, block_livre);
////		
////		inserir_inode_triplo(disco, block_livre, quantidade_blocos);
////		//TEM QUE MOREVER A PROPRIA ESTRTUTURA 
////	}
////	
////	//EXTENSAO, COMO FAZER?
////	if(quantidade_blocos)
////	{
////		//O QUE FAZER?
////	}
////}

////void inserir_arquivo_diretorio(Block block_arquivo, int inode_numero, char nome_arq[255])
////{
////	/*
////		ESTA FUNCAO INSERE UM ARQUIVO NUMA ESTRUTURA DE DIRETORIO
////		NA POSICAO TL � INSERIDO O NUMERO DO INODE E O NOME DO ARQUIVO
////	*/
////	int tl_estrutura_dir;
////	
////	tl_estrutura_dir = block_arquivo.diretorio.tl;
////	
////	if(tl_estrutura_dir < 10)
////	{
////		
////		block_arquivo.diretorio.i_numero[tl_estrutura_dir] = inode_numero; 
////		strcpy(block_arquivo.diretorio.nome_arq[tl_estrutura_dir], nome_arq); 
////		
////		block_arquivo.diretorio.tl++;
////		
////	}
////	int tl_block_top;
////	
////	//push_lista_pilha(lp, tl_lista, block);
////	
////	if(*tl_dir < 13)
////	{
////		tl_block_top = dir[*tl_dir-1].tl;
////		dir[*tl_dir-1].nome_arq = block.diretorio.nome_arq;
////		dir[*tl_dir-1].i_numero = block.diretorio.i_numero;
////		(*tl_dir)++;
////	}
////	else
////	{
////		printf("\n- Diretorio cheio. Criando novo diretorio.");
////		Block b = criar_diretorio("Novo diretorio");
////		b.diretorio.tl = 1;
////		dir[0].nome_arq = block.diretorio.nome_arq;
////		dir[0].i_numero = block.diretorio.i_numero;
////	}
////}

////fun��o - chmod 
//void alterar_permissao (char nome[15])
//{
//	//nome come�a da posi��o 1, pois o 0 � o sinal
//}

////fun��o - Is
//void listar_nomes_arq_dir ()
//{
//	
//}

////fun��o - Is -I
//void listar_nomes_arq_atributos()
//{
//	
//}

////fun��o - df
//void espaco_livre_ocupado()
//{
//	
//}

////fun��o - vi nomeArquivo
//void visualizar_arquivo_regular(char arq[15])
//{
//	
//}

////fun��o - mkdir
//void criar_diretorio(char nome[15])
//{
//	
//}

////fun��o rmdir
//void deletar_diretorio_vazio(char nome[15])
//{
//	
//}

////fun��o - rm
//void deletar_arquivo(char nome[15])
//{
//	
//}

////fu��o cd
//void cd(char nome[15], char n[3])
//{
//	
//}

////fun��o -  link �h  
//void link_fisico(char origem[15], char destino[15])
//{
//	
//}

////fun��o -  link �s
//void link_simbolico(char origem[15], char destino[15])
//{
//	
//}

////fun��o unlink - h
//void unlink_fisico()
//{
//	
//}

////fun��o unlink - s
//void unlink_simbolico()
//{
//	
//}

////fun��o bad
//void bad(int num)
//{
//	
//}

////fun��o touch
//void touch(char nome[15], int num)
//{
//	
//}


//void ler_comando()
//{
//	char linha[30], comando[15], nome[15], n1[15], n2[15];
//	int i, j, num;
//	bool ok;
//	
//	while(strcmp(comando,"exit") != 0)
//	{

//		printf("- ");
//		scanf("%[^\n]s",&linha);
//		setbuf(stdin, NULL);
//		
//		for(i = 0; linha[i] != '\0'; i++)
//			linha[i] = tolower(linha[i]);
//		
//		for(i = 0; linha[i] != '\0'; )
//		{
//			for(j = 0; linha[i] !=' ' && linha[i] !='\0'; j++)
//				comando[j] = linha[i++];
//			comando[j] = '\0';
//				
//			if(linha[i] !='\0')
//				i++;
//			
//			for(j = 0; linha[i] !=' ' && linha[i] !='\0'; j++)
//				nome[j] = linha[i++];
//			nome[j] = '\0';
//				
//			if(linha[i] !='\0')
//				i++;
//				
//			for(j = 0; linha[i] !=' ' && linha[i] !='\0'; j++)
//				n1[j] = linha[i++];
//			n1[j] = '\0';
//			
//			if(linha[i] !='\0')
//				i++;
//				
//			for(j = 0; linha[i] !=' ' && linha[i] !='\0'; j++)
//				n2[j] = linha[i++];
//			n2[j] = '\0';
//		}
//	
//	
//		if(strcmp(comando,"is") != 0 && strcmp(comando,"df") != 0)
//		{
//			if(strcmp(comando,"chmod") == 0)
//				alterar_permissao(nome);
//			else
//				if(strcmp(comando,"vi") == 0)
//					visualizar_arquivo_regular(nome);
//				else
//					if(strcmp(comando,"mkdir") == 0)	
//						criar_diretorio(nome);
//					else
//						if(strcmp(comando,"rmdir") == 0)	
//							deletar_diretorio_vazio(nome);	
//						else
//							if(strcmp(comando,"rm") == 0)	
//								deletar_arquivo(nome);
//							else
//								if(strcmp(comando,"cd") == 0)
//								{
//									if(strcmp(n1, ".") == 0 || strcmp(n1, "..") == 0)
//										cd(nome, n1);
//									else
//										printf("- Forma de navegacao invalida.");
//								}
//								else
//									if(strcmp(comando,"link") == 0)
//									{
//										if(strcmp(nome, "-h") == 0 && strcmp(n1, "") != 0 && strcmp(n2, "") != 0)
//											link_fisico(n1,n2);
//										else
//											if(strcmp(nome, "-s") == 0 && strcmp(n1, "") != 0 && strcmp(n2, "") != 0)
//												link_simbolico(n1,n2);
//											else
//												printf("- Opcao de link  ou nomes de arquivos invalidos.");
//									}
//									else
//										if(strcmp(comando,"unlink") == 0)
//										{
//											if(strcmp(nome, "-h") == 0)
//												unlink_fisico();
//											else
//												if(strcmp(nome, "-s") == 0)
//													unlink_simbolico();
//												else
//													printf("- Opcao de link invalida.");
//										}
//										else
//											if(strcmp(comando,"bad") == 0)
//											{
//												ok = true;
//												for(j = 0; nome[j] !='\0'; j++)
//													if(nome[j] != '0' && nome[j] != '1' && nome[j] != '2' && nome[j] != '3' && nome[j] != '4' && nome[j] != '5' && nome[j] != '6' && nome[j] != '7' && nome[j] != '8' && nome[j] != '9')
//														ok = false;
//												if(ok)
//												{
//													num = atoi(nome);
//													bad(num);
//												}
//												else
//													printf("- Numero invalido.");
//											}
//											else
//												if(strcmp(comando,"touch") == 0)	
//												{
//													ok = true;
//													for(j = 0; nome[j] !='\0'; j++)
//														if(nome[j] != '0' && nome[j] != '1' && nome[j] != '2' && nome[j] != '3' && nome[j] != '4' && nome[j] != '5' && nome[j] != '6' && nome[j] != '7' && nome[j] != '8' && nome[j] != '9')
//															ok = false;
//													
//													if(ok)
//													{
//														num = atoi(nome);
//														touch(nome, num);
//													}
//													else
//														printf("- Numero invalido.");
//												}
//												else
//													printf("- Opcao invalida");	
//		}
//		else
//		{
//			if(strcmp(comando,"ls") == 0)
//			{
//				if(strcmp(nome,"")==0)
//					listar_nomes_arq_dir();
//				else
//					if(strcmp(nome,"-l")==0)
//						listar_nomes_arq_atributos();
//					else
//						printf("- Opcao invalida.");
//			}	
//			else
//				espaco_livre_ocupado();
//		}
//		printf("\n");

//	}
//}


